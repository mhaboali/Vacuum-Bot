#include <ros/ros.h>
#include <tf/transform_broadcaster.h>
#include "LinkStates.h"
#include "Quaternion.h"
//std::string turtle_name;

float odom_x , odom_y , odom_z , odom_quat_x , odom_quat_y , odom_quat_z , odom_quat_w ;
int count=0 ;


void dropodom (const gazebo_msgs::LinkStates M ){

  static tf::TransformBroadcaster br0;
  tf::Transform transform0;
  if (count == 0){
	odom_x = M.pose[1].position.x ;
	odom_y = M.pose[1].position.y ;
	odom_z = 0 ;
	odom_quat_x=M.pose[1].orientation.x;
	odom_quat_y=M.pose[1].orientation.y;
	odom_quat_z=M.pose[1].orientation.z;
	odom_quat_w=M.pose[1].orientation.w;
		}

  transform0.setOrigin( tf::Vector3(odom_x, odom_y , odom_z) );
  //tf::Quaternion q;
  //q.setRPY(0, 0, msg->theta);
  tf::Quaternion q0	(odom_quat_x,
	                 odom_quat_y, 
                         odom_quat_z,
                         odom_quat_w ) ;
  transform0.setRotation(q0);
  br0.sendTransform(tf::StampedTransform(transform0, ros::Time::now(), "world", "odom"));
  count = 1;

}


void poseCallback(const gazebo_msgs::LinkStates P){

  // odom -> urban_base_link

  static tf::TransformBroadcaster br1;
  tf::Transform transform1;
  double x1= P.pose[1].position.x - odom_x ;
  double y1= P.pose[1].position.y - odom_y ;
  double z1= 0 ;
  transform1.setOrigin( tf::Vector3(x1,y1,z1) );
  //tf::Quaternion q;
  //q.setRPY(0, 0, msg->theta);
  tf::Quaternion q_baselink_world	(P.pose[1].orientation.x,
	                                 P.pose[1].orientation.y, 
                                         P.pose[1].orientation.z,
                                         P.pose[1].orientation.w ) ;

  tf::Quaternion q_odom_world	        (odom_quat_x ,
	                                 odom_quat_y , 
                                         odom_quat_z ,
                                         odom_quat_w ) ;
  tf::Quaternion q_baselink_odom ;
  q_baselink_odom = q_baselink_world * tf::inverse(q_odom_world);
  transform1.setRotation(q_baselink_odom);
  br1.sendTransform(tf::StampedTransform(transform1, ros::Time::now(), "odom", "base_link"));


  // urban_base_link -> vlp-16

  static tf::TransformBroadcaster br2;
  tf::Transform transform2;
  double x= P.pose[1].position.x - P.pose[9].position.x ;
  double y= P.pose[1].position.y - P.pose[9].position.y ;
  double z= P.pose[1].position.z - P.pose[9].position.z ;
  transform2.setOrigin( tf::Vector3(x,y,z) );
  //tf::Quaternion q;
  //q.setRPY(0, 0, msg->theta);
  tf::Quaternion q_scans_world	(P.pose[9].orientation.x,
	                         P.pose[9].orientation.y, 
                                 P.pose[9].orientation.z,
                                 P.pose[9].orientation.w ) ;
  tf::Quaternion q_scans_baselink ; 


  q_scans_baselink = q_scans_world * tf::inverse(q_baselink_odom);
  transform2.setRotation(q_scans_baselink);
  br2.sendTransform(tf::StampedTransform(transform2, ros::Time::now(), "base_link", "scans"));
}







int main(int argc, char** argv){

  

  ros::init(argc, argv, "urban_tf");
  //if (argc != 2){ROS_ERROR("need turtle name as argument"); return -1;};
 // turtle_name = argv[1];
  ros::NodeHandle node0;
  ros::Subscriber sub0 = node0.subscribe("/gazebo/link_states", 10, &dropodom);
  ros::spinOnce() ;

  ros::NodeHandle node;
  ros::Subscriber sub = node.subscribe("/gazebo/link_states", 10, &poseCallback);

  ros::spin();
  return 0;
};
